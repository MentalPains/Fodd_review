var comment_url = "/restaurant";
var restaurant_array = []; // This creates an empty restaurant array
var foodCount = 0;
/*  There are couple categories: "Now Showing" and "Coming Soon". This variable states which 
    category of restaurants should be listed when the home page is first loaded. */
var category = "Now Showing";
var currentIndex = 0;
var comment_url = "/comments";
var comment_array = []; // This creates an empty comment array
var popcornBWImage = 'images/popcorn_bw.png';
var popcornImage = 'images/popcorn.png';
var rating = 0;
